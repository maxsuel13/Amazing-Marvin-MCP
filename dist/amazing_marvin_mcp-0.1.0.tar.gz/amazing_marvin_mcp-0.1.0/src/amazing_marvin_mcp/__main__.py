"""Entry point for running amazing_marvin_mcp as a module."""

from .main import start

if __name__ == "__main__":
    start()