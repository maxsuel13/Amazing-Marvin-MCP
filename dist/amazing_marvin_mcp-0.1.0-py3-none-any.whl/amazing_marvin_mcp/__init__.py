"""Amazing Marvin Model Context Provider"""

from .main import start, mcp
from .api import MarvinAPIClient
from .config import get_settings

__version__ = "0.1.0"
